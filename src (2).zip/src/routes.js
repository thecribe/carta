export const LOGIN = "/login";
export const ROOT = "/";

//PUBLIC ROUTES

export const PUBLIC_ROUTES = ["/login", "/api", "/directory"];
