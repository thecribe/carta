import React, { Fragment } from "react";
import ManageFellow from "./ui/ManageFellow";

const page = () => {
  return (
    <Fragment>
      <section className="p-8 h-full">
        <ManageFellow />
      </section>
    </Fragment>
  );
};

export default page;
